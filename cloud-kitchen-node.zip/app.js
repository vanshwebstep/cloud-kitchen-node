import 'dotenv/config';
import 'tsx/esm';

await import('./src/index.ts');
